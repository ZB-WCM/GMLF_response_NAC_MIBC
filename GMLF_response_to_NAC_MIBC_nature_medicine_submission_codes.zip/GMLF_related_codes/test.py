import os
ROOT_OUTPUT_DIR = '/home/zbai/tiatoolbox/Output/' 
import joblib

CACHE_PATH = f'{ROOT_OUTPUT_DIR}/splits_80v20_test_holdout_stra_cr.dat'
SPLIT_PATH = f'{ROOT_OUTPUT_DIR}/splits_80v20_test_holdout_stra_cr.dat'

NUM_FOLDS = 10
TEST_RATIO = 0.2
TRAIN_RATIO = 0.8 * 0.75
VALID_RATIO = 0.8 * 0.25

if CACHE_PATH and os.path.exists(CACHE_PATH):
    print(f"Using precomputed splits from {CACHE_PATH}")
    splits = joblib.load(CACHE_PATH)

print([v[0] for v in splits[0]['train']])
print([v[0] for v in splits[0]['valid']])
print([v[0] for v in splits[0]['test']])

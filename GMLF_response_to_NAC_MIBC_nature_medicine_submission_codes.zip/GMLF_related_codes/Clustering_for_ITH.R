rm(list=ls())

library(NbClust)

data_dir = '/home/zbai/tiatoolbox/cancer_cell_level_nuc_morph/nuc_morph/'
for (fn in list.files(data_dir)) {
  nmf_mat <- read.csv(paste(data_dir, fn, sep=""))
  print(nmf_mat)
  print(dim(nmf_mat))
  print(colnames(nmf_mat))
  res <- NbClust(data = nmf_mat, distance = "euclidean", method = "ward.D2")
  print(length(res$Best.partition))
}

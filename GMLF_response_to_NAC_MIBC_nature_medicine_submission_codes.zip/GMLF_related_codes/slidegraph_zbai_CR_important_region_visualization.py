# Important region visualization by Zilong Bai
# Python standard library imports
import openslide
import cv2
from collections import OrderedDict
import copy
import os
import pathlib
import random
import shutil
import sys
from typing import Callable, List, Tuple
import warnings

# Third party imports
import joblib
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL.Image import new
import torch
from tqdm import tqdm
# Use ujson as replacement for default json because it's faster for large JSON
import ujson as json

warnings.filterwarnings("ignore")

# ! save_yaml, save_as_json => need same name, need to factor out jsonify
from tiatoolbox.utils.misc import imread, save_as_json

mpl.rcParams['figure.dpi'] = 300  # for high resolution figure in notebook

def get_region(slide_id, pos, level, size):
    slide = openslide.OpenSlide(slide_id+'.svs')
    img = slide.read_region(pos, level, size).convert('RGB')

    return img

level = 0
size = 2048

# Fetch most important regions from NE graph
# Top 3
# Bottom 3

# Fetch most important regions from CTandMF graph
# Top 3
# Bottom 3

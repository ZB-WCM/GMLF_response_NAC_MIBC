import numpy as np
import pandas as pd

ROOT_OUTPUT_DIR = '/home/zbai/tiatoolbox/Output/'

df_shap_values_test = pd.read_csv(f'{ROOT_OUTPUT_DIR}/CRvsRest_modality_features_test_predictions_shap.csv', index_col=0)
df_shap_values_valid = pd.read_csv(f'{ROOT_OUTPUT_DIR}/CRvsRest_modality_features_valid_predictions_shap.csv', index_col=0)
df_shap_values_train = pd.read_csv(f'{ROOT_OUTPUT_DIR}/CRvsRest_modality_features_train_predictions_shap.csv', index_col=0)

df_shap_values_all = pd.concat([df_shap_values_train, df_shap_values_valid, df_shap_values_test], ignore_index=True, axis=0)

df_shap_values_all.to_csv(f'{ROOT_OUTPUT_DIR}/all_patient_shap_values_labels.csv')

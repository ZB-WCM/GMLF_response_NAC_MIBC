# Python standard library imports
import openslide
import cv2
from collections import OrderedDict
import copy
import os
import pathlib
import random
import shutil
import sys
from typing import Callable, List, Tuple
import warnings

# Third party imports
import joblib
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL.Image import new
import torch
from tqdm import tqdm
# Use ujson as replacement for default json because it's faster for large JSON
import ujson as json

warnings.filterwarnings("ignore")

# ! save_yaml, save_as_json => need same name, need to factor out jsonify
from tiatoolbox.utils.misc import imread, save_as_json

mpl.rcParams['figure.dpi'] = 300  # for high resolution figure in notebook

###########################################################################
def load_json(path: str):
    """Load JSON from a file path."""
    with open(path, "r") as fptr:
        json_dict = json.load(fptr)
    return json_dict


def rmdir(dir_path: str):
    """Remove a directory."""
    if os.path.isdir(dir_path):
        shutil.rmtree(dir_path)
    return


def rm_n_mkdir(dir_path: str):
    """Remove then re-create a directory."""
    if os.path.isdir(dir_path):
        shutil.rmtree(dir_path)
    os.makedirs(dir_path)
    return


def mkdir(dir_path: str):
    """Create a directory if it does not exist."""
    if not os.path.isdir(dir_path):
        os.makedirs(dir_path)
    return


def recur_find_ext(root_dir: str, exts: List[str]) -> List[str]:
    """Recursively find files with an extension in `exts`.

    This is much faster than glob if the folder
    hierachy is complicated and contain > 1000 files.

    Args:
        root_dir (str):
            Root directory for searching.
        exts (list):
            List of extensions to match.

    Returns:
        List of full paths with matched extension in sorted order.

    """
    assert isinstance(exts, list)
    file_path_list = []
    for cur_path, dir_list, file_list in os.walk(root_dir):
        for file_name in file_list:
            file_ext = pathlib.Path(file_name).suffix
            if file_ext in exts:
                full_path = os.path.join(cur_path, file_name)
                file_path_list.append(full_path)
    file_path_list.sort()
    return file_path_list
 
######################################################################

SEED = 5
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed(SEED)

######################################################################

# Set these variables to run next cell either
# seperately or with customized parameters
#ROOT_OUTPUT_DIR = '/athena/ihlab/scratch/mbb4001/Bladder/TIAToolbox/Output/'
#WSI_DIR = '/athena/ihlab/scratch/mbb4001/Bladder/TIAToolbox/BLCA_SVS/'
#MSK_DIR = None
#CLINICAL_FILE = '/athena/ihlab/scratch/mbb4001/Bladder/TIAToolbox/slide_names.csv' ## FILL OUT

ROOT_OUTPUT_DIR = '/home/zbai/tiatoolbox/Output/'
WSI_DIR = '/home/zbai/Faltas_image/'
MSK_DIR = '/home/zbai/Faltas_image_segmentation/masks_v2/masks'
CLINICAL_FILE = '/home/zbai/tiatoolbox/Output/slide_names_uncms.csv' ## FILL OUT

######################################################################

wsi_paths = recur_find_ext(WSI_DIR, [".svs", ".ndpi"])
wsi_names = [pathlib.Path(v).stem for v in wsi_paths]

print(len(wsi_names))


msk_paths = None if MSK_DIR is None else [f"{MSK_DIR}/{v}.png" for v in wsi_names]
assert len(wsi_paths) > 0, "No files found."


clinical_df = pd.read_csv(CLINICAL_FILE)
patient_uids = clinical_df["case_id"].to_numpy()
patient_labels = clinical_df["UNC.subtype"].to_numpy()

patient_labels_ = np.full_like(patient_labels, -1)
patient_labels_[patient_labels == "Basal"] = 1
patient_labels_[patient_labels == "Luminal"] = 0

sel = patient_labels_ >= 0

patient_uids = patient_uids[sel]
patient_labels = patient_labels_[sel]
assert len(patient_uids) == len(patient_labels)
clinical_info = OrderedDict(list(zip(patient_uids, patient_labels)))
print(clinical_info)
wsi_patient_codes = np.array([v.split("-")[0] for v in wsi_names])
print(wsi_patient_codes)
wsi_labels = np.array(
    [clinical_info[v] if v in clinical_info else np.nan for v in wsi_patient_codes]
)
print(wsi_labels)

sel = ~np.isnan(wsi_labels)
# Simple sanity checks before filtering
assert len(wsi_paths) == len(wsi_names)
assert len(wsi_paths) == len(wsi_labels)

print(wsi_labels)
print(sel)

wsi_paths = np.array(wsi_paths)[sel]
wsi_names = np.array(wsi_names)[sel]
wsi_labels = np.array(wsi_labels)[sel]

print(wsi_paths, wsi_names, wsi_labels)



label_df = list(zip(wsi_names, wsi_labels))
label_df = pd.DataFrame(label_df, columns=["WSI-CODE", "LABEL"])

from sklearn.model_selection import StratifiedShuffleSplit


def stratified_split2(
        x_orig: List,
        y: List,
        train: float,
        valid: float,
        test: float,
        num_folds: int,
        seed: int = 5):
    import random
    assert train + valid + test - 1.0 < 1.0e-10, "Ratios must sum to 1.0 ."

    x = [v.split('-')[0] for v in x_orig]
    #print(x)

    pats = list(set(x))
    splits = []



    for xyz in range(num_folds):
        #print(pats)
        random.shuffle(pats)
        train_pats = pats[:int(len(pats)*train)]

        print(int(len(pats)*train),int(len(pats)*(train+valid)))
        val_pats = pats[int(len(pats)*train):int(len(pats)*(train+valid))]
        test_pats = pats[int(len(pats)*(train+valid)):]
        #print(len(pats))
        #print(len(train_pats)+len(val_pats)+len(test_pats))
        assert len(pats) == len(train_pats)+len(val_pats)+len(test_pats)
         
        train_x = []
        train_y = []
        valid_x = []
        valid_y = []
        test_x = []
        test_y = []
        print(val_pats)

        for abc in val_pats:
            #print('test')
            #print(abc)
            #print(np.flatnonzero(np.core.defchararray.find(x, abc)!=-1))
            ghi = np.flatnonzero(np.core.defchararray.find(x, abc)!=-1).astype(int)
            sub_x = [x_orig[q] for q in ghi]
            sub_y = [y[q] for q in ghi]
            for cc in range(len(sub_x)):
                valid_x.append(sub_x[cc])
                valid_y.append(sub_y[cc])
            

        for abc in train_pats:
            #print('test')
            #print(abc)
            #print(np.flatnonzero(np.core.defchararray.find(x, abc)!=-1))
            ghi = np.flatnonzero(np.core.defchararray.find(x, abc)!=-1).astype(int)
            sub_x = [x_orig[q] for q in ghi]
            sub_y = [y[q] for q in ghi]
            for cc in range(len(sub_x)):
                train_x.append(sub_x[cc])
                train_y.append(sub_y[cc])

        for abc in test_pats:
            #print('test')
            #print(abc)
            #print(np.flatnonzero(np.core.defchararray.find(x, abc)!=-1))
            ghi = np.flatnonzero(np.core.defchararray.find(x, abc)!=-1).astype(int)
            sub_x = [x_orig[q] for q in ghi]
            sub_y = [y[q] for q in ghi]
            for cc in range(len(sub_x)):
                test_x.append(sub_x[cc])
                test_y.append(sub_y[cc])


        assert len(set(train_x).intersection(set(valid_x))) == 0
        assert len(set(valid_x).intersection(set(test_x))) == 0
        assert len(set(train_x).intersection(set(test_x))) == 0


        splits.append(
            {
                "train": list(zip(train_x, train_y)),
                "valid": list(zip(valid_x, valid_y)),
                "test": list(zip(test_x, test_y)),
            }
        )

    return splits
'''
    assert train + valid + test - 1.0 < 1.0e-10, "Ratios must sum to 1.0 ."

    outer_splitter = StratifiedShuffleSplit(
        n_splits=num_folds,
        train_size=train + valid,
        random_state=seed
    )
    inner_splitter = StratifiedShuffleSplit(
        n_splits=1,
        train_size=train / (train + valid),
        random_state=seed,
    )

    x = np.array(x)
    y = np.array(y)
    splits = []
    for train_valid_idx, test_idx in outer_splitter.split(x, y):
        test_x = x[test_idx]
        test_y = y[test_idx]

        # Holder for train_valid set
        x_ = x[train_valid_idx]
        y_ = y[train_valid_idx]

        # Split train_valid into train and valid set
        train_idx, valid_idx = list(inner_splitter.split(x_, y_))[0]
        valid_x = x_[valid_idx]
        valid_y = y_[valid_idx]

        train_x = x_[train_idx]
        train_y = y_[train_idx]

        # Integrity check
        assert len(set(train_x).intersection(set(valid_x))) == 0
        assert len(set(valid_x).intersection(set(test_x))) == 0
        assert len(set(train_x).intersection(set(test_x))) == 0

'''
CACHE_PATH = f'{ROOT_OUTPUT_DIR}/splits_train_val_5fCV_stra_uncms.dat'
SPLIT_PATH = f'{ROOT_OUTPUT_DIR}/splits_train_val_5fCV_stra_uncms.dat'

NUM_FOLDS = 10
TEST_RATIO = 0.2
TRAIN_RATIO = 0.8 * 0.75
VALID_RATIO = 0.8 * 0.25

if CACHE_PATH and os.path.exists(CACHE_PATH):
    print(f"Using precomputed splits from {CACHE_PATH}")
    splits = joblib.load(CACHE_PATH)
    SPLIT_PATH = CACHE_PATH
else:
    assert False, 'This should not be called.'
    x = np.array(label_df["WSI-CODE"].to_list())
    y = np.array(label_df["LABEL"].to_list())
    splits = stratified_split2(
        x, y,
        TRAIN_RATIO, VALID_RATIO, TEST_RATIO,
        NUM_FOLDS)
    
    joblib.dump(splits, SPLIT_PATH)
##################################################################
from tiatoolbox.models import DeepFeatureExtractor, IOSegmentorConfig
from tiatoolbox.models.architecture import CNNBackbone


def extract_deep_features(
        wsi_paths: List[str],
        msk_paths: List[str],
        save_dir: str,
        preproc_func: Callable = None):
    ioconfig = IOSegmentorConfig(
        input_resolutions=[
            {"units": "mpp", "resolution": 0.497},
        ],
        output_resolutions=[
            {"units": "mpp", "resolution": 0.497},
        ],
        patch_input_shape=[1024,1024],
        patch_output_shape=[1024,1024],
        stride_shape=[1024,1024],
        save_resolution={"units": "mpp", "resolution": 8.0},
    )
    model = CNNBackbone("resnet50")
    extractor = DeepFeatureExtractor(
        batch_size=8, model=model, num_loader_workers=10)
    # Injecting customized preprocessing functions,
    # check the document or sample code below for API.
    extractor.model.preproc_func = preproc_func

    rmdir(save_dir)
    output_map_list = extractor.predict(
        wsi_paths,
        msk_paths,
        mode="wsi",
        ioconfig=ioconfig,
        on_gpu=True,
        crash_on_exception=False,
        save_dir=save_dir,
    )

    # Rename output files
    for input_path, output_path in output_map_list:
        input_name = pathlib.Path(input_path).stem

        output_parent_dir = pathlib.Path(output_path).parent

        src_path = pathlib.Path(f'{output_path}.position.npy')
        new_path = pathlib.Path(f'{output_parent_dir}/{input_name}.position.npy')
        src_path.rename(new_path)

        src_path = pathlib.Path(f'{output_path}.features.0.npy')
        new_path = pathlib.Path(f'{output_parent_dir}/{input_name}.features.npy')
        src_path.rename(new_path)

    return output_map_list
########################################################################################
from tiatoolbox.wsicore.wsireader import get_wsireader
from tiatoolbox.models import NucleusInstanceSegmentor
from tiatoolbox.tools.patchextraction import PatchExtractor
from shapely.geometry import box as shapely_box
from shapely.strtree import STRtree


def get_cell_compositions(
            wsi_path: str,
            inst_pred_path: str,
            save_dir: str,
            num_types: int = 6,
            patch_input_shape: Tuple[int] = (512, 512),
            stride_shape: Tuple[int] = (512, 512),
            resolution: float = 0.25,
            units: str = 'mpp',
        ):
    """
    Args:
        out_path (str): Path pointing to file containing nucleus
            instance predictions, assumed to be from tiatoolbox.

    """

    reader = get_wsireader(wsi_path)
    inst_pred = joblib.load(inst_pred_path)
    # Convert to {key: int, value: dict}
    inst_pred = {
        i: v for i, (_, v) in enumerate(inst_pred.items())
    }

    inst_boxes = [v['box'] for v in inst_pred.values()]
    inst_boxes = np.array(inst_boxes)

    geometries = [shapely_box(*bounds) for bounds in inst_boxes]
    # An auxiliary dictionary to actually query the index within the source list
    index_by_id = {id(geo): idx for idx, geo in enumerate(geometries)}
    spatial_indexer = STRtree(geometries)

    # * Generate patch coordinates (in xy format)
    wsi_shape = reader.slide_dimensions(resolution=resolution, units=units)

    (patch_inputs, _) = PatchExtractor.get_coordinates(
        image_shape=wsi_shape,
        patch_input_shape=patch_input_shape,
        patch_output_shape=patch_input_shape,
        stride_shape=stride_shape,
    )

    bounds_compositions = []
    for bounds in patch_inputs:
        bounds_ = shapely_box(*bounds)
        indices = [
            index_by_id[id(geo)]
            for geo in spatial_indexer.query(bounds_)
            if bounds_.contains(geo)
        ]
        insts = [inst_pred[v]['type'] for v in indices]
        uids, freqs = np.unique(insts, return_counts=True)
        # A bound may not contain all types, hence, to sync
        # the array and placement across all types, we create
        # a holder then fill the count within.
        holder = np.zeros(num_types, dtype=np.int16)
        holder[uids] = freqs
        bounds_compositions.append(holder)
    bounds_compositions = np.array(bounds_compositions)

    base_name = pathlib.Path(wsi_path).stem
    # Output in the same saving protocol for construct graph
    np.save(f'{save_dir}/{base_name}.position.npy', patch_inputs)
    np.save(f'{save_dir}/{base_name}.features.npy', bounds_compositions)


def extract_composition_features(
        wsi_paths: List[str],
        msk_paths: List[str],
        save_dir: str,
        preproc_func: Callable):
    inst_segmentor = NucleusInstanceSegmentor(
        pretrained_model="hovernet_fast-pannuke",
        batch_size=16,
        num_postproc_workers=2,
    )
    # Injecting customized preprocessing functions,
    # check the document or sample codes below for API
    inst_segmentor.model.preproc_func = preproc_func

    rmdir(save_dir)
    output_map_list = inst_segmentor.predict(
        wsi_paths,
        msk_paths,
        mode="wsi",
        on_gpu=True,
        crash_on_exception=True,
        save_dir=save_dir,
    )
    # Rename output files of toolbox
    output_paths = []
    for input_path, output_path in output_map_list:
        input_name = pathlib.Path(input_path).stem

        output_parent_dir = pathlib.Path(output_path).parent

        src_path = pathlib.Path(f'{output_path}.dat')
        new_path = pathlib.Path(f'{output_parent_dir}/{input_name}.dat')
        src_path.rename(new_path)
        output_paths.append(new_path)

    # TODO: parallelize this later if possible
    for idx, path in enumerate(output_paths):
        get_cell_compositions(wsi_paths[idx], path, save_dir)
    return output_paths
#########################################################################################
from tiatoolbox.data import stain_norm_target
from tiatoolbox.tools.stainnorm import get_normalizer

target_image = stain_norm_target()
stain_normalizer = get_normalizer("vahadane")
stain_normalizer.fit(target_image)

def stain_norm_func(img):
    return stain_normalizer.transform(img)
#########################################################################################
NUM_NODE_FEATURES = 2048
FEATURE_MODE = "cnn"
CACHE_PATH = f"{ROOT_OUTPUT_DIR}/featurescnn_res_v2/"
#CACHE_PATH = None #f"{ROOT_OUTPUT_DIR}featurescnn"
WSI_FEATURE_DIR = f"{ROOT_OUTPUT_DIR}/featurescnn_res_v2/"
#WSI_FEATURE_DIR = f"{ROOT_OUTPUT_DIR}featurescnn"
######################################################################################
if CACHE_PATH and os.path.exists(CACHE_PATH):
    print(f"Using extracted CNN features from {CACHE_PATH}")
    output_list = recur_find_ext(f"{CACHE_PATH}/", [".npy"])
elif FEATURE_MODE == "composition":
    output_list = extract_composition_features(
        wsi_paths, msk_paths, WSI_FEATURE_DIR, stain_norm_func)
else:
    assert False, 'This should not be called.'
    output_list = extract_deep_features(
        wsi_paths, msk_paths, WSI_FEATURE_DIR, stain_norm_func)
# assert len(output_list) == len(wsi_names), \
#             f'Missing output. {len(output_list)} vs {len(wsi_names)}'

######################################################################################
CACHE_PATH = f"{ROOT_OUTPUT_DIR}/graph_res_v2/"
GRAPH_DIR = f"{ROOT_OUTPUT_DIR}/graph_res_v2/"
###################################################################
from tiatoolbox.tools.graph import SlideGraphConstructor


def construct_graph(wsi_name, save_path):
    """Construct graph for one WSI and save to file."""
    positions = np.load(f"{WSI_FEATURE_DIR}/{wsi_name}.position.npy")
    features = np.load(f"{WSI_FEATURE_DIR}/{wsi_name}.features.npy")
    graph_dict = SlideGraphConstructor.build(
                    positions[:, :2], features,
                    feature_range_thresh=None)
    print("This should NOT be called!") # This function should not be called in the new setting. The graphs are already constructed. We add new component into the slidegraphDataset.

    # Write a graph to a JSON file
    with open(save_path, "w") as handle:
        graph_dict = {k: v.tolist() for k, v in graph_dict.items()}
        json.dump(graph_dict, handle)


if CACHE_PATH and os.path.exists(CACHE_PATH):
    print(f"Using constructed graph data structure from {CACHE_PATH}")
    GRAPH_DIR = CACHE_PATH  # assignment for follow up loading
    graph_paths = recur_find_ext(f"{CACHE_PATH}/", [".json"])
else:
    rm_n_mkdir(GRAPH_DIR)
    graph_paths = [
        construct_graph(v, f"{GRAPH_DIR}/{v}.json")
        for v in wsi_names
    ]
# ! put the assertion back later
assert len(graph_paths) == len(wsi_names), 'Missing output.'
###########################################################################
NUM_NODE_FEATURES = 35 # TODO: need to have the correct feature vector dimensionality.
FEATURE_MODE = "cfnmf"
CACHE_PATH = f"{ROOT_OUTPUT_DIR}/CFandNMF/NMF/Nuc_Seg_NMF_Patch_MorphOnly_raw/"
#CACHE_PATH = None #f"{ROOT_OUTPUT_DIR}featurescnn"
WSI_FEATURE_DIR = f"{ROOT_OUTPUT_DIR}/CFandNMF/NMF/Nuc_Seg_NMF_Patch_MorphOnly_raw/"
#WSI_FEATURE_DIR = f"{ROOT_OUTPUT_DIR}featurescnn"
######################################################################################
if CACHE_PATH and os.path.exists(CACHE_PATH):
    print(f"Using extracted cell-type features from {CACHE_PATH}")
    output_list = recur_find_ext(f"{CACHE_PATH}/", [".npy"])
elif FEATURE_MODE == "composition":
    output_list = extract_composition_features(
        wsi_paths, msk_paths, WSI_FEATURE_DIR, stain_norm_func)
else:
    print("This should NOT be called!")
    output_list = extract_deep_features(
        wsi_paths, msk_paths, WSI_FEATURE_DIR, stain_norm_func)
# assert len(output_list) == len(wsi_names), \
#             f'Missing output. {len(output_list)} vs {len(wsi_names)}'
###########################################################################
CACHE_CT_PATH = f"{ROOT_OUTPUT_DIR}/graph_Nuc_Seg_NMF_Patch_MorphOnly_raw_prec/" # Load from cell-type graphs
GRAPH_CT_DIR = f"{ROOT_OUTPUT_DIR}/graph_Nuc_Seg_NMF_Patch_MorphOnly_raw_prec/" # Build graphs for cell-type info
###################################################################
from tiatoolbox.tools.graph import SlideGraphConstructor


def construct_graph(wsi_name, save_path):
    """Construct graph for one WSI and save to file."""
    positions = np.load(f"{WSI_FEATURE_DIR}/{wsi_name}.position.npy")
    features = np.load(f"{WSI_FEATURE_DIR}/{wsi_name}.features.npy")
    graph_dict = SlideGraphConstructor.build(
                    positions[:, :2], features,
                    feature_range_thresh=None)
    print("This should NOT be called!") # This function should not be called in the new setting. The graphs are already constructed. We add new component into the slidegraphDataset.

    # Write a graph to a JSON file
    with open(save_path, "w") as handle:
        graph_dict = {k: v.tolist() for k, v in graph_dict.items()}
        json.dump(graph_dict, handle)


if CACHE_CT_PATH and os.path.exists(CACHE_CT_PATH):
    print(f"Using constructed cell-type graph data structure from {CACHE_CT_PATH}")
    GRAPH_CT_DIR = CACHE_CT_PATH  # assignment for follow up loading
    graph_paths = recur_find_ext(f"{CACHE_CT_PATH}/", [".json"])
else:
    print(f"We should NOT be using this branch!!! Building cell-type graph data structure based on {WSI_FEATURE_DIR}, and will save into {GRAPH_DIR}")
    rm_n_mkdir(GRAPH_CT_DIR)
    graph_paths = [
        construct_graph(v, f"{GRAPH_CT_DIR}/{v}.json")
        for v in wsi_names
    ]
# ! put the assertion back later
print(len(graph_paths))
print(len(wsi_names))
assert len(graph_paths) == len(wsi_names), 'Missing output.'

###########################################################################
from torch_geometric.data import Data, Dataset
from torch_geometric.loader import DataLoader


class SlideGraphDataset(Dataset):
    """Handling loading graph data from disk.

    Args:
        info_list (list): In case of `train` or `valid` is in `mode`,
            this is expected to be a list of `[uid, label]` . Otherwise,
            it is a list of `uid`. Here, `uid` is used to construct
            `f"{GRAPH_DIR}/{wsi_code}.json"` which is a path points to
            a `.json` file containing the graph structure. By `label`, we mean
            the label of the graph. The format within the `.json` file comes
            from `tiatoolbox.tools.graph`.
        mode (str): This denotes which data mode the `info_list` is in.
        preproc (callable): The prerocessing function for each node
            within the graph.

    """

    def __init__(self, info_list, mode="train", preproc=None): 
        self.info_list = info_list
        self.mode = mode
        self.preproc = preproc

    def __getitem__(self, idx):
        info = self.info_list[idx]
        if any(v in self.mode for v in ['train', 'valid']):
            wsi_code, label = info
            # torch.Tensor will create 1-d vector not scalar
            label = torch.tensor(label)
        else:
            wsi_code = info

        with open(f"{GRAPH_DIR}/{wsi_code}.json", "r") as fptr:
            graph_dict = json.load(fptr)
        graph_dict = {k: np.array(v) for k, v in graph_dict.items()}

        if self.preproc is not None:
            graph_dict["x"] = self.preproc(graph_dict["x"])
            #graph_dict["x_ct"] = self.preproc_ct(graph_dict["x_ct"])

        graph_dict = {k: torch.tensor(v) for k, v in graph_dict.items()}
        graph = Data(**graph_dict)

        if any(v in self.mode for v in ['train', 'valid']):
            return dict(graph=graph, label=label)
        return dict(graph=graph)

    def __len__(self):
        return len(self.info_list)

class SlideGraphDataset_ct(Dataset): # Defined specifically for cell-type information
    """Handling loading graph data from disk.

    Args:
        info_list (list): In case of `train` or `valid` is in `mode`,
            this is expected to be a list of `[uid, label]` . Otherwise,
            it is a list of `uid`. Here, `uid` is used to construct
            `f"{GRAPH_CT_DIR}/{wsi_code}.json"` which is a path points to
            a `.json` file containing the graph structure. By `label`, we mean
            the label of the graph. The format within the `.json` file comes
            from `tiatoolbox.tools.graph`.
        mode (str): This denotes which data mode the `info_list` is in.
        preproc (callable): The prerocessing function for each node
            within the graph.

    """

    def __init__(self, info_list, mode="train", preproc=None): # Added preproc_ct by Zilong to normalize cell-type attributed graph.
        self.info_list = info_list
        self.mode = mode
        self.preproc = preproc

    def __getitem__(self, idx):
        info = self.info_list[idx]
        if any(v in self.mode for v in ['train', 'valid']):
            wsi_code, label = info
            # torch.Tensor will create 1-d vector not scalar
            label = torch.tensor(label)
        else:
            wsi_code = info

        with open(f"{GRAPH_CT_DIR}/{wsi_code}.json", "r") as fptr: #modified specifically for cell-type attributed graph
            graph_dict = json.load(fptr)
        graph_dict = {k: np.array(v) for k, v in graph_dict.items()}

        if self.preproc is not None:
            graph_dict["x"] = self.preproc(graph_dict["x"])
            #graph_dict["x_ct"] = self.preproc_ct(graph_dict["x_ct"])

        graph_dict = {k: torch.tensor(v) for k, v in graph_dict.items()}
        graph = Data(**graph_dict)

        if any(v in self.mode for v in ['train', 'valid']):
            return dict(graph=graph, label=label)
        return dict(graph=graph)

    def __len__(self):
        return len(self.info_list)


import joblib
from sklearn.preprocessing import StandardScaler

CACHE_PATH = f"{ROOT_OUTPUT_DIR}/node_scaler_res.dat" #None
SCALER_PATH = f"{ROOT_OUTPUT_DIR}/node_scaler_res.dat"


if CACHE_PATH and os.path.exists(CACHE_PATH):
    print(f"Using precomputed node_scaler from {CACHE_PATH}")
    SCALER_PATH = CACHE_PATH  # assignment for follow up loading
    node_scaler = joblib.load(SCALER_PATH)
else:
    # ! we need a better way of doing this, will have OOM problem
    loader = SlideGraphDataset(wsi_names, mode="infer")
    loader = DataLoader(
        loader,
        num_workers=8,
        batch_size=1,
        shuffle=False,
        drop_last=False
    )
    node_features = [
        v['graph'].x.numpy() for idx, v in enumerate(tqdm(loader))]
    node_features = np.concatenate(node_features, axis=0)
    node_scaler = StandardScaler(copy=False)
    node_scaler.fit(node_features)
    joblib.dump(node_scaler, SCALER_PATH)

# we must define the function after training/loading
def nodes_preproc_func(node_features):
    return node_scaler.transform(node_features)


CACHE_PATH = f"{ROOT_OUTPUT_DIR}/node_scaler_Nuc_Seg_NMF_Patch_MorphOnly_raw.dat" #None
SCALER_CT_PATH = f"{ROOT_OUTPUT_DIR}/node_scaler_Nuc_Seg_NMF_Patch_MorphOnly_raw.dat"


if CACHE_PATH and os.path.exists(CACHE_PATH):
    print(f"Using precomputed node_scaler_ct from {CACHE_PATH}")
    SCALER_CT_PATH = CACHE_PATH  # assignment for follow up loading
    node_scaler_ct = joblib.load(SCALER_CT_PATH)
else:
    # ! we need a better way of doing this, will have OOM problem
    print(f"NOTE SUPPOSED TO BE HERE!")
    loader = SlideGraphDataset(wsi_names, mode="infer")
    loader = DataLoader(
        loader,
        num_workers=8,
        batch_size=1,
        shuffle=False,
        drop_last=False
    )
    node_features = [
        v['graph'].x.numpy() for idx, v in enumerate(tqdm(loader))]
    node_features = np.concatenate(node_features, axis=0)
    node_scaler = StandardScaler(copy=False)
    node_scaler.fit(node_features)
    joblib.dump(node_scaler, SCALER_PATH)


def nodes_preproc_func_ct(node_features):
    return node_scaler_ct.transform(node_features)

#####################################################################
NUM_NODE_FEATURES = 2048

#####################################################################
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import BatchNorm1d, Linear, ReLU
from torch_geometric.nn import (
    EdgeConv,
    GINConv,
    global_add_pool,
    global_max_pool,
    global_mean_pool,
)


class SlideGraphArch(nn.Module):
    def __init__(
        self,
        dim_features,
        dim_target,
        layers=[6, 6],
        pooling="max",
        dropout=0.0,
        conv="GINConv",
        gembed=False,
        **kwargs,
    ):
        super().__init__()
        self.dropout = dropout
        self.embeddings_dim = layers
        self.num_layers = len(self.embeddings_dim)
        self.nns = []
        self.convs = []
        self.linears = []
        self.pooling = {
            "max": global_max_pool,
            "mean": global_mean_pool,
            "add": global_add_pool,
        }[pooling]
        # If True then learn a graph embedding for final classification
        # (classify pooled node features), otherwise pool node decision scores.
        self.gembed = gembed

        self.nns_ct = [] # Added by Zilong for Cell-type information branch
        self.convs_ct = [] # Added by Zilong for Cell-type information branch
        self.linears_ct = [] # Added by Zilong for Cell-type information branch

        conv_dict = {"GINConv": [GINConv, 1], "EdgeConv": [EdgeConv, 2]}
        if conv not in conv_dict:
            raise ValueError(f'Not support `conv="{conv}".')

        def create_linear(in_dims, out_dims):
            return nn.Sequential(
                Linear(in_dims, out_dims), BatchNorm1d(out_dims), ReLU()
            )

        def create_linear_gex(in_dims, mid_dims, out_dims): # Zilong add for late fusion.
            return nn.Sequential(
                Linear(in_dims, mid_dims[0]),
                BatchNorm1d(mid_dims[0]),
                ReLU(),
                Linear(mid_dims[0], mid_dims[1]),
                BatchNorm1d(mid_dims[1]),
                ReLU(),
                Linear(mid_dims[1], mid_dims[2]),
                BatchNorm1d(mid_dims[2]),
                ReLU(),
                Linear(mid_dims[2], out_dims),
                BatchNorm1d(out_dims),
                ReLU()
            )

        input_emb_dim = dim_features
        out_emb_dim = self.embeddings_dim[0]
        self.first_h = create_linear(input_emb_dim, out_emb_dim)
        self.linears.append(Linear(out_emb_dim, dim_target))

        #dim_gex_features = 1071 # Input gex feature dimension to be the same as nodal feature dimension of GNN.

        #self.gex_mlp = create_linear_gex(dim_gex_features, self.embeddings_dim, dim_target) # Zilong add for late fusion.

        input_emb_dim = out_emb_dim
        for out_emb_dim in self.embeddings_dim[1:]:
            ConvClass, alpha = conv_dict[conv]
            subnet = create_linear(alpha * input_emb_dim, out_emb_dim)
            # ! this variable should be removed after training integrity checking
            self.nns.append(subnet)  # <--| as it already within ConvClass
            self.convs.append(ConvClass(self.nns[-1], **kwargs))
            self.linears.append(Linear(out_emb_dim, dim_target))
            input_emb_dim = out_emb_dim

        self.nns = torch.nn.ModuleList(self.nns)
        self.convs = torch.nn.ModuleList(self.convs)
        # Has got one more for initial input, what does this mean
        self.linears = torch.nn.ModuleList(self.linears)


        input_emb_dim_ct = 35 # TODO: need to be consistent with cell-type attributed graph nodal feature vector dimensionality
        out_emb_dim = self.embeddings_dim[0]
        self.first_h_ct = create_linear(input_emb_dim_ct, out_emb_dim) # Added by Zilong for Cell-type information branch
        self.linears_ct.append(Linear(out_emb_dim, dim_target)) # Added by Zilong for Cell-type information branch

        input_emb_dim = out_emb_dim
        for out_emb_dim in self.embeddings_dim[1:]:
            ConvClass, alpha = conv_dict[conv]
            subnet_ct = create_linear(alpha * input_emb_dim, out_emb_dim)
            # ! this variable should be removed after training integrity checking
            self.nns_ct.append(subnet_ct)  # <--| as it already within ConvClass
            self.convs_ct.append(ConvClass(self.nns_ct[-1], **kwargs))
            self.linears_ct.append(Linear(out_emb_dim, dim_target))
            input_emb_dim = out_emb_dim

        self.nns_ct = torch.nn.ModuleList(self.nns_ct)
        self.convs_ct = torch.nn.ModuleList(self.convs_ct)
        # Has got one more for initial input, what does this mean
        self.linears_ct = torch.nn.ModuleList(self.linears_ct)

        # Auxilary holder for external model, these are saved separately from torch.save
        # as they can be sklearn model etc.
        self.aux_model = {}

    def save(self, path, aux_path):
        state_dict = self.state_dict()
        torch.save(state_dict, path)
        joblib.dump(self.aux_model, aux_path)

    def load(self, path, aux_path):
        state_dict = torch.load(path)
        self.load_state_dict(state_dict)
        self.aux_model = joblib.load(aux_path)

    def forward(self, data, data_ct):

        feature, edge_index, batch = data.x, data.edge_index, data.batch
        #gex_feature = data.gex  # Load gex data, in the same split as the graph features, in the same data structure that stored the graph data. 
        # gex_feature needs reshape.
        #lv = len(gex_feature)
        #dim_gex_feature = 1071 
        #nr = lv // 1071
        #gex_feature = torch.reshape(gex_feature, (nr, dim_gex_feature))

        feature_ct, edge_index_ct, batch_ct = data_ct.x, data_ct.edge_index, data_ct.batch # Added by Zilong to integrate cell-type attributed graph.

        #print(f"What is batch: {batch}")

        #print(f"batch:{batch}")
        #print(f"gex feature shape: {gex_feature.shape}")
        #print(f"feature shape: {feature.shape}")

        wsi_prediction = 0
        pooling = self.pooling
        node_prediction = 0

        feature = self.first_h(feature)
        for layer in range(self.num_layers):
            if layer == 0:
                node_prediction_sub = self.linears[layer](feature)
                node_prediction += node_prediction_sub
                node_pooled = pooling(node_prediction_sub, batch)
                wsi_prediction_sub = F.dropout(
                    node_pooled, p=self.dropout, training=self.training
                )
                wsi_prediction += wsi_prediction_sub
            else:
                feature = self.convs[layer - 1](feature, edge_index)
                if not self.gembed:
                    node_prediction_sub = self.linears[layer](feature)
                    node_prediction += node_prediction_sub
                    node_pooled = pooling(node_prediction_sub, batch)
                    wsi_prediction_sub = F.dropout(
                        node_pooled, p=self.dropout, training=self.training
                    )
                else:
                    node_pooled = pooling(feature, batch)
                    node_prediction_sub = self.linears[layer](node_pooled)
                    wsi_prediction_sub = F.dropout(
                        node_prediction_sub, p=self.dropout, training=self.training
                    )
                wsi_prediction += wsi_prediction_sub
        #gex_prediction = self.gex_mlp(gex_feature)
        #wsi_prediction += gex_prediction

        ################## FOLLOWING SECTION: Added by Zilong to integrate cell-type attributed graph.

        wsi_prediction_ct = 0
        pooling = self.pooling
        node_prediction_ct = 0

        feature_ct = self.first_h_ct(feature_ct)
        for layer in range(self.num_layers):
            if layer == 0:
                node_prediction_sub_ct = self.linears_ct[layer](feature_ct)
                node_prediction_ct += node_prediction_sub_ct
                node_pooled_ct = pooling(node_prediction_sub_ct, batch_ct)
                wsi_prediction_sub_ct = F.dropout(
                    node_pooled_ct, p=self.dropout, training=self.training
                )
                wsi_prediction_ct += wsi_prediction_sub_ct
            else:
                feature_ct = self.convs_ct[layer - 1](feature_ct, edge_index_ct)
                if not self.gembed:
                    node_prediction_sub_ct = self.linears_ct[layer](feature_ct)
                    node_prediction_ct += node_prediction_sub_ct
                    node_pooled_ct = pooling(node_prediction_sub_ct, batch_ct)
                    wsi_prediction_sub = F.dropout(
                        node_pooled_ct, p=self.dropout, training=self.training
                    )
                else:
                    node_pooled_ct = pooling(feature_ct, batch_ct)
                    node_prediction_sub_ct = self.linears_ct[layer](node_pooled_ct)
                    wsi_prediction_sub_ct = F.dropout(
                        node_prediction_sub_ct, p=self.dropout, training=self.training
                    )
                wsi_prediction_ct += wsi_prediction_sub_ct

        wsi_prediction += wsi_prediction_ct

        ##############################################################################################

        return wsi_prediction, node_prediction

    # Run one single step
    @staticmethod
    def train_batch(model, batch_data, batch_data_ct, on_gpu, optimizer: torch.optim.Optimizer):
        wsi_graphs = batch_data["graph"].to("cuda") # NOTE: Zilong added gex at the WSI level to the "graph" element in the Data structure.
        wsi_labels = batch_data["label"].to("cuda")
        wsi_graphs_ct = batch_data_ct["graph"].to("cuda")

        # Data type conversion
        wsi_graphs.x = wsi_graphs.x.type(torch.float32)
        #wsi_graphs.gex = wsi_graphs.gex.type(torch.float32) # NOTE: Zilong added gex at the WSI level to the "graph" element in the Data structure.
        wsi_graphs_ct.x = wsi_graphs_ct.x.type(torch.float32) # NOTE: Zilong added cell-type attributed graphs to the "graph" element in the Data structure.

        # Not an RNN so does not accumulate
        model.train()
        optimizer.zero_grad()

        wsi_output, _ = model(wsi_graphs, wsi_graphs_ct)

        # Both are expected to be Nx1
        wsi_labels_ = wsi_labels[:, None]
        wsi_labels_ = wsi_labels_ - wsi_labels_.T
        wsi_output_ = wsi_output - wsi_output.T
        diff = wsi_output_[wsi_labels_ > 0]
        loss = torch.mean(F.relu(1.0 - diff))
        # Backprop and update
        loss.backward()
        optimizer.step()

        #
        loss = loss.detach().cpu().numpy()
        assert not np.isnan(loss)
        wsi_labels = wsi_labels.cpu().numpy()
        return [loss, wsi_output, wsi_labels]

    # Run one inference step
    @staticmethod
    def infer_batch(model, batch_data, batch_data_ct, on_gpu):
        wsi_graphs = batch_data["graph"].to("cuda")
        wsi_graphs_ct = batch_data_ct["graph"].to("cuda")

        # Data type conversion
        wsi_graphs.x = wsi_graphs.x.type(torch.float32)
        #wsi_graphs.gex = wsi_graphs.gex.type(torch.float32)  # NOTE: Zilong added gex at the WSI level to the "graph" element in the Data structure.
        wsi_graphs_ct.x = wsi_graphs_ct.x.type(torch.float32) # NOTE: Zilong added cell-type attributed graphs to the "graph" element in the Data structure.

        # Inference mode
        model.eval()
        # Do not compute the gradient (not training)
        with torch.inference_mode():
            wsi_output, _ = model(wsi_graphs, wsi_graphs_ct)

        wsi_output = wsi_output.cpu().numpy()
        # Output should be a single tensor or scalar
        if "label" in batch_data:
            wsi_labels = batch_data["label"]
            wsi_labels = wsi_labels.cpu().numpy()
            return wsi_output, wsi_labels
        return [wsi_output]

###############################################################
dummy_ds = SlideGraphDataset(wsi_names, mode="infer")
dummy_ds_ct = SlideGraphDataset_ct(wsi_names, mode="infer")
loader = DataLoader(
    dummy_ds,
    num_workers=0,
    batch_size=8,
    shuffle=False,
)
loader_ct = DataLoader(
    dummy_ds_ct,
    num_workers=0,
    batch_size=8,
    shuffle=False,
)

iterator = iter(loader)
batch_data = iterator.__next__()

iterator_ct = iter(loader_ct)
batch_data_ct = iterator_ct.__next__()

# Data type conversion
wsi_graphs = batch_data["graph"]
wsi_graphs.x = wsi_graphs.x.type(torch.float32)
#wsi_graphs.gex = wsi_graphs.gex.type(torch.float32)  # NOTE: Zilong added gex at the WSI level to the "graph" element in the Data structure.

wsi_graphs_ct = batch_data_ct["graph"]
wsi_graphs_ct.x = wsi_graphs_ct.x.type(torch.float32) # NOTE: Zilong added cell-type attributed graphs to the "graph" element in the Data structure.

print(f"wsi_graphs.keys():{wsi_graphs}")
print(f"wsi_graphs_ct.keys():{wsi_graphs_ct}")

#print(f"wsi_graphs.x shape: {wsi_graphs.x.shape}")
#print(f"wsi_graphs.gex shape: {wsi_graphs.gex.shape}")
#print(f"wsi_graphs.edge_index shape: {wsi_graphs.edge_index.shape}")
#print(f"batch len: {len(wsi_graphs.batch)}")
#print(f"wsi_graphs.gex: {wsi_graphs.gex}")

# Define model object
arch_kwargs = dict(
    dim_features=NUM_NODE_FEATURES,
    dim_target=1,
    layers=[16, 16, 8],
    dropout=0.5,
    pooling="max",
    conv="EdgeConv",
    aggr="max",
)
model = SlideGraphArch(**arch_kwargs)

# Inference section
model.eval()
with torch.inference_mode():
    output, _ = model(wsi_graphs, wsi_graphs_ct)
    output = output.cpu().numpy()
print(output)
##################################################################
from sklearn.model_selection import StratifiedKFold
from torch.utils.data import Sampler


class StratifiedSampler(Sampler):
    """Sampling the dataset such that the batch contains stratified samples.

    Args:
        labels (list): List of labels, must be in the same ordering as input
            samples provided to the `SlideGraphDataset` object.
        batch_size (int): Size of the batch.
    Returns:
        List of indices to query from the `SlideGraphDataset` object.

    """

    def __init__(self, labels, batch_size=10):
        self.batch_size = batch_size
        self.num_splits = int(len(labels) / self.batch_size)
        self.labels = labels
        self.num_steps = self.num_splits

    def _sampling(self):
        # do we want to control randomness here
        skf = StratifiedKFold(n_splits=self.num_splits, shuffle=True)
        indices = np.arange(len(self.labels))  # idx holder
        # return array of arrays of indices in each batch
        return [tidx for _, tidx in skf.split(indices, self.labels)]

    def __iter__(self):
        return iter(self._sampling())

    def __len__(self):
        """The length of the sampler.

        This value actually corresponds to the number of steps to query
        sampled batch indices. Thus, to maintain epoch and steps hierarchy,
        this should be equal to the number of expected steps as in usual
        sampling: `steps=dataset_size / batch_size`.

        """
        return self.num_steps
########################################################################
def create_pbar(subset_name: str, num_steps: int):
    """Create a nice progress bar."""
    pbar_format = (
        'Processing: |{bar}| {n_fmt}/{total_fmt}'
        '[{elapsed}<{remaining},{rate_fmt}]'
    )
    pbar = tqdm(
            total=num_steps,
            leave=True,
            bar_format=pbar_format,
            ascii=True)
    if subset_name == 'train':
        pbar_format += (
            'step={postfix[1][step]:0.5f}'
            '|EMA={postfix[1][EMA]:0.5f}'
        )
        # * Changing print char may break the bar so avoid it
        pbar = tqdm(
                total=num_steps,
                leave=True,
                initial=0,
                bar_format=pbar_format,
                ascii=True,
                postfix=['', dict(step=float('NaN'), EMA=float('NaN'))])
    return pbar


class ScalarMovingAverage(object):
    """Class to calculate running average."""

    def __init__(self, alpha=0.95):
        super().__init__()
        self.alpha = alpha
        self.tracking_dict = {}

    def __call__(self, step_output):
        for key, current_value in step_output.items():
            if key in self.tracking_dict:
                old_ema_value = self.tracking_dict[key]
                # Calculate the exponential moving average
                new_ema_value = (
                    old_ema_value * self.alpha + (1.0 - self.alpha) * current_value
                )
                self.tracking_dict[key] = new_ema_value
            else:  # Init for variable which appear for the first time
                new_ema_value = current_value
                self.tracking_dict[key] = new_ema_value
####################################################################
import logging

from sklearn.metrics import average_precision_score as auprc_scorer
from sklearn.metrics import roc_auc_score as auroc_scorer

#from tiatoolbox.tools.scale import PlattScaling
from sklearn.linear_model import LogisticRegression as PlattScaling

def run_once(
        dataset_dict, num_epochs, save_dir,
        on_gpu=True, pretrained=None,
        loader_kwargs={}, arch_kwargs={}, optim_kwargs={}):
    """Running the inference or training loop once.

    The actual running mode is defined via the code name of the dataset
    within `dataset_dict`. Here, `train` is specifically preserved for
    the dataset used for training. `.*infer-valid.*` and `.*infer-train*`
    are reserved for datasets containing the corresponding labels.
    Otherwise, the dataset is assumed to be for the inference run.

    """
    model = SlideGraphArch(**arch_kwargs)
    if pretrained is not None:
        model.load(*pretrained)
    model = model.to("cuda")
    optimizer = torch.optim.Adam(model.parameters(), **optim_kwargs)

    # Create the graph dataset holder for each subset info then
    # pipe them through torch/torch geometric specific loader
    # for loading in multi-thread.
    loader_dict = {}
    loader_ct_dict = {}
    for subset_name, subset in dataset_dict.items():
        _loader_kwargs = copy.deepcopy(loader_kwargs)
        batch_sampler = None
        if subset_name == 'train':
            _loader_kwargs = {}
            batch_sampler = StratifiedSampler(
                labels=[v[1] for v in subset],
                batch_size=loader_kwargs['batch_size']
            )

        ds = SlideGraphDataset(
            subset, mode=subset_name, preproc=nodes_preproc_func)
        loader_dict[subset_name] = DataLoader(
            ds,
            batch_sampler=batch_sampler,
            drop_last=subset_name == "train" and batch_sampler is None,
            shuffle=subset_name == "train" and batch_sampler is None,
            **_loader_kwargs,
        )
        ds_ct = SlideGraphDataset_ct(
            subset, mode=subset_name, preproc=nodes_preproc_func_ct)
        loader_ct_dict[subset_name] = DataLoader(
            ds_ct,
            batch_sampler=batch_sampler,
            drop_last=subset_name == "train" and batch_sampler is None,
            shuffle=subset_name == "train" and batch_sampler is None,
            **_loader_kwargs,
        )

    for epoch in range(num_epochs):
        logging.info(f"EPOCH {epoch:03d}")
        for loader_name, loader in loader_dict.items():
            # * EPOCH START
            step_output = []
            ema = ScalarMovingAverage()
            pbar = create_pbar(loader_name, len(loader))
            loader_ct = loader_ct_dict[loader_name]
            for step, [batch_data, batch_data_ct] in enumerate(zip(loader, loader_ct)):
                #batch_data_ct = loader_ct[step]
                # * STEP COMPLETE CALLBACKS
                if loader_name == "train":
                    output = model.train_batch(model, batch_data, batch_data_ct, on_gpu, optimizer)
                    # check the output for agreement
                    ema({"loss": output[0]})
                    pbar.postfix[1]["step"] = output[0]
                    pbar.postfix[1]["EMA"] = ema.tracking_dict['loss']
                else:
                    output = model.infer_batch(model, batch_data, batch_data_ct, on_gpu)

                    batch_size = batch_data["graph"].num_graphs
                    # Iterate over output head and retrieve
                    # each as N x item, each item may be of
                    # arbitrary dimensions
                    output = [np.split(v, batch_size, axis=0) for v in output]
                    # pairing such that it will be
                    # N batch size x H head list
                    output = list(zip(*output))
                    step_output.extend(output)
                pbar.update()
            pbar.close()

            # * EPOCH COMPLETE

            # Callbacks to process output
            logging_dict = {}
            if loader_name == "train":
                for val_name, val in ema.tracking_dict.items():
                    logging_dict[f"train-EMA-{val_name}"] = val
            elif ("infer" in loader_name and
                    any(v in loader_name for v in ["train", "valid"])):
                # Expand the list of N dataset size x H heads
                # back to a list of H Head each with N samples.
                output = list(zip(*step_output))
                logit, true = output
                logit = np.squeeze(np.array(logit))
                true = np.squeeze(np.array(true))

                if "train" in loader_name:
                    scaler = PlattScaling()
                    #scaler.fit(logit, true)
                    scaler.fit(np.array(logit, ndmin=2).T, true) # Fixed
                    model.aux_model['scaler'] = scaler
                scaler = model.aux_model['scaler']
                #prob = scaler.transform(logit)
                prob = scaler.predict_proba(np.array(logit, ndmin=2).T)[:, 0] # Mistake was found. Not np.darray. Changed into np.array

                val = auroc_scorer(true, prob)
                logging_dict[f"{loader_name}-auroc"] = val
                val = auprc_scorer(true, prob)
                logging_dict[f"{loader_name}-auprc"] = val

                logging_dict[f"{loader_name}-raw-logit"] = logit
                logging_dict[f"{loader_name}-raw-true"] = true

            # Callbacks for logging and saving
            for val_name, val in logging_dict.items():
                if 'raw' not in val_name:
                    logging.info(f"{val_name}: {val}")
            if "train" not in loader_dict:
                continue

            # Track the statistics
            new_stats = {}
            if os.path.exists(f"{save_dir}/stats.json"):
                old_stats = load_json(f"{save_dir}/stats.json")
                # Save a backup first
                save_as_json(old_stats, f"{save_dir}/stats.old.json", exist_ok=True) # Changed exist_ok flag to True to allow overwrite.
                new_stats = copy.deepcopy(old_stats)
                new_stats = {int(k): v for k, v in new_stats.items()}

            old_epoch_stats = {}
            if epoch in new_stats:
                old_epoch_stats = new_stats[epoch]
            old_epoch_stats.update(logging_dict)  # Indent mistake rewinded 
            new_stats[epoch] = old_epoch_stats  # Indent mistake rewinded
            save_as_json(new_stats, f"{save_dir}/stats.json", exist_ok=True)  # Indent mistake rewinded. Changed exist_ok flag to True to allow overwrite.

            # Debugging lines
            print(logging_dict)

            # Save the pytorch model
            model.save(
                f"{save_dir}/epoch={epoch:03d}.weights.pth",
                f"{save_dir}/epoch={epoch:03d}.aux.dat"
            )
    return step_output
#####################################################################################
logging.basicConfig(level=logging.INFO,)


def reset_logging(save_path):
    """Reset logger handler."""
    log_formatter = logging.Formatter(
        '|%(asctime)s.%(msecs)03d| [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d|%H:%M:%S'
    )
    log = logging.getLogger()     # Root logger
    for hdlr in log.handlers[:]:  # Remove all old handlers
        log.removeHandler(hdlr)
    new_hdlr_list = [
        logging.FileHandler(f"{save_path}/debug.log"),
        logging.StreamHandler()
    ]
    for hdlr in new_hdlr_list:
        hdlr.setFormatter(log_formatter)
        log.addHandler(hdlr)
########################################################################################
# Default parameters
NUM_EPOCHS = 100 
NUM_NODE_FEATURES = 2048
SCALER_PATH = f"{ROOT_OUTPUT_DIR}/node_scaler_res.dat"
MODEL_DIR = f"{ROOT_OUTPUT_DIR}/model_graph_cnn_graph_Nuc_Seg_NMF_Patch_MorphOnly_raw_5fCV_uncms_maxpooling/"

SCALER_CT_PATH = f"{ROOT_OUTPUT_DIR}/node_scaler_Nuc_Seg_NMF_Patch_MorphOnly_raw.dat"
##@####################################################################################
splits = joblib.load(SPLIT_PATH)
node_scaler = joblib.load(SCALER_PATH)
node_scaler_ct = joblib.load(SCALER_CT_PATH)

loader_kwargs = dict(
    num_workers=8,
    batch_size=16,
)
arch_kwargs = dict(
    dim_features=NUM_NODE_FEATURES,
    dim_target=1,
    layers=[16, 16, 8],
    dropout=0.5,
    pooling="max",
    conv="EdgeConv",
    aggr="max",
)
optim_kwargs = dict(
    lr=1.0e-3,
    weight_decay=1.0e-4,
)


if not os.path.exists(MODEL_DIR):
    for split_idx, split in enumerate(splits):
        new_split = {
            "train": split['train'],
            "infer-train": split['train'],
            "infer-valid-A": split['valid'],
            "infer-valid-B": split['test'],
        }
        split_save_dir = f"{MODEL_DIR}/{split_idx:02d}/"
        rm_n_mkdir(split_save_dir)
        reset_logging(split_save_dir)
        run_once(
            new_split, NUM_EPOCHS,
            save_dir=split_save_dir,
            arch_kwargs=arch_kwargs,
            loader_kwargs=loader_kwargs,
            optim_kwargs=optim_kwargs)
###########################################################################################
def select_checkpoints(
        stat_file_path: str,
        top_k: int = 2,
        metric: str = "infer-valid-auprc",
        epoch_range: Tuple[int] = [0, 1000]):
    """Select checkpoints basing on training statistics.

    Args:
        stat_file_path (str): Path pointing to the .json
            which contains the statistics.
        top_k (int): Number of top checkpoints to be selected.
        metric (str): The metric name saved within .json to perform
            selection.
        epoch_range (list): The range of epochs for checking, denoted
            as [start, end] . Epoch x that is `start <= x <= end` is
            kept for further selection.
    Returns:
        paths (list): List of paths or info tuple where each point
            to the correspond check point saving location.
        stats (list): List of corresponding statistics.

    """
    """
        Testing: Changing metric from "infer-valid-auprc" to "infer-valid-A-auprc", which means the auprc measure of "infer-valid-A": split['valid']
    """

    stats_dict = load_json(stat_file_path)
    # k is the epoch counter in this case
    stats_dict = {
        k: v for k, v in stats_dict.items()
        if int(k) >= epoch_range[0] and int(k) <= epoch_range[1]
    }
    # Debugging lines
    for k,v in stats_dict.items():
        print(v.keys())
    stats = [[int(k), v[metric], v] for k, v in stats_dict.items()]
    # sort epoch ranking from largest to smallest
    stats = sorted(stats, key=lambda v: v[1], reverse=True)
    chkpt_stats_list = stats[:top_k]  # select top_k

    model_dir = pathlib.Path(stat_file_path).parent
    epochs = [v[0] for v in chkpt_stats_list]
    paths = [(
        f"{model_dir}/epoch={epoch:03d}.weights.pth",
        f"{model_dir}/epoch={epoch:03d}.aux.dat")
        for epoch in epochs
    ]
    chkpt_stats_list = [[v[0], v[2]] for v in chkpt_stats_list]
    print(paths)
    return paths, chkpt_stats_list
############################################################################################
# default parameters
TOP_K = 1
metric_name = 'infer-valid-B-auroc'
PRETRAINED_DIR = f"{ROOT_OUTPUT_DIR}/model_graph_cnn_graph_Nuc_Seg_NMF_Patch_MorphOnly_raw_5fCV_uncms_maxpooling/"
SCALER_PATH = f"{ROOT_OUTPUT_DIR}/node_scaler_res.dat"

SCALER_CT_PATH = f"{ROOT_OUTPUT_DIR}/node_scaler_Nuc_Seg_NMF_Patch_MorphOnly_raw.dat"
##########################################################################################
splits = joblib.load(SPLIT_PATH)
node_scaler = joblib.load(SCALER_PATH)

node_scaler_ct = joblib.load(SCALER_CT_PATH)
loader_kwargs = dict(
    num_workers=8,
    batch_size=16,
)
arch_kwargs = dict(
    dim_features=NUM_NODE_FEATURES,
    dim_target=1,
    layers=[16, 16, 8],
    dropout=0.5,
    pooling="max",
    conv="EdgeConv",
    aggr="max",
)

cum_stats = []
for split_idx, split in enumerate(splits):
    new_split = {
        "infer": [v[0] for v in split["test"]]
    }

    stat_files = recur_find_ext(f'{PRETRAINED_DIR}/{split_idx:02d}/', [".json"])
    stat_files = [v for v in stat_files if ".old.json" not in v]
    print(stat_files)
    assert len(stat_files) == 1
    chkpts, chkpt_stats_list = select_checkpoints(
        stat_files[0], top_k=TOP_K, metric=metric_name)

    # Perform ensembling by averaging probabilities
    # across checkpoint predictions
    cum_results = []
    for chkpt_info in chkpts:
        chkpt_results = run_once(
            new_split,
            num_epochs=1,
            save_dir=None,
            pretrained=chkpt_info,
            arch_kwargs=arch_kwargs,
            loader_kwargs=loader_kwargs,
        )
        # * re-calibrate logit to probabilities
        model = SlideGraphArch(**arch_kwargs)
        model.load(*chkpt_info)
        scaler = model.aux_model['scaler']
        chkpt_results = np.array(chkpt_results)
        chkpt_results = np.squeeze(chkpt_results)
        # Debugging lines
        print(chkpt_results)
        #chkpt_results = scaler.transform(chkpt_results)
        # chkpt_results = scaler.predict_proba(chkpt_results) # Changed to use the scaler defined by LogisticRegression
        chkpt_results = scaler.predict_proba(np.array(chkpt_results, ndmin=2).T)[:, 0]

        cum_results.append(chkpt_results)
    cum_results = np.array(cum_results)
    cum_results = np.squeeze(cum_results)

    prob = cum_results
    if len(cum_results.shape) == 2:
        prob = np.mean(cum_results, axis=0)

    # * Calculate split statistics
    true = [v[1] for v in split["test"]]
    true = np.array(true)

    cum_stats.append({
        'auroc': auroc_scorer(true, prob),
        'auprc': auprc_scorer(true, prob)
    })
############################################################################################
stat_df = pd.DataFrame(cum_stats)
for metric in stat_df.columns:
    vals = stat_df[metric]
    mu = np.mean(vals)
    va = np.std(vals)
    print(f'{metric}: {mu:0.4f}±{va:0.4f}')

































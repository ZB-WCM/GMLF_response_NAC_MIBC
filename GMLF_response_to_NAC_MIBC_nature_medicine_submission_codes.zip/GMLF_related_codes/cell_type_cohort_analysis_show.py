import numpy as np
import pandas as pd
import scipy.stats as stats
import pingouin as pg
import statsmodels.api as sm
import pylab as py
from matplotlib import pyplot as plt

ROOT_OUTPUT_DIR = '/home/zbai/tiatoolbox/Output/'

ct_features_df = pd.read_csv(f'{ROOT_OUTPUT_DIR}/interpretation_important_patch_summary.csv', index_col = 0)
cell_types = ['cancer', 'immune', 'connective', 'necrotic', 'non-cancer']
ct_features_df.index = cell_types
print(ct_features_df)
ct_features_prop_df = pd.DataFrame()
for col in ct_features_df.columns:
    ct_features_prop_df[col] = (ct_features_df[col] / ct_features_df[col].sum()) #* 100
print(ct_features_prop_df)

df_shap_values_test = pd.read_csv(f'{ROOT_OUTPUT_DIR}/CRvsRest_modality_features_test_predictions_shap.csv', index_col=0)
df_shap_values_valid = pd.read_csv(f'{ROOT_OUTPUT_DIR}/CRvsRest_modality_features_valid_predictions_shap.csv', index_col=0)
df_shap_values_train = pd.read_csv(f'{ROOT_OUTPUT_DIR}/CRvsRest_modality_features_train_predictions_shap.csv', index_col=0)

df_shap_values_all = pd.concat([df_shap_values_train, df_shap_values_valid, df_shap_values_test], ignore_index=True, axis=0)

print(df_shap_values_train)
print(df_shap_values_valid)
print(df_shap_values_test)
print(df_shap_values_all)

ct_count_t_coef = []
ct_count_t_pval = []
ct_prop_t_coef = []
ct_prop_t_pval = []

N = df_shap_values_all.shape[0]

ct_count_ttest_df = pd.DataFrame(columns=['T', 'dof', 'alternative', 'p-val', 'CI95%', 'cohen-d', 'BF10', 'power'])
ct_prop_ttest_df = pd.DataFrame(columns=['T', 'dof', 'alternative', 'p-val', 'CI95%', 'cohen-d', 'BF10', 'power'])

ct_count_kwtest_df = pd.DataFrame(columns=['statistic', 'pval']) 
ct_prop_kwtest_df = pd.DataFrame(columns=['statistic', 'pval'])

for ct in cell_types:
    ct_count = ct_features_df.loc[ct]
    ct_prop = ct_features_prop_df.loc[ct]
    print(ct_count)
    print(ct_prop)

    count_group1 = ct_count[df_shap_values_all.loc[df_shap_values_all['groundtruth CRvsRest'] == 1]['patient slide id']]
    count_group0 = ct_count[df_shap_values_all.loc[df_shap_values_all['groundtruth CRvsRest'] == 0]['patient slide id']]

    prop_group1 = ct_prop[df_shap_values_all.loc[df_shap_values_all['groundtruth CRvsRest'] == 1]['patient slide id']]
    prop_group0 = ct_prop[df_shap_values_all.loc[df_shap_values_all['groundtruth CRvsRest'] == 0]['patient slide id']]

    count_group1 = np.array(count_group1)
    count_group0 = np.array(count_group0)

    prop_group1 = np.array(prop_group1)
    prop_group0 = np.array(prop_group0)

    assert (len(count_group0) + len(count_group1)) == N, "Missing instances in count"

    assert (len(prop_group0) + len(prop_group1)) == N, "Missing instances in prop"

    if (np.mean(prop_group1) > np.mean(prop_group0)):
        print(f"{ct}:Higher in CR")
    else:
        print(f"{ct}:Higher in N/PR")

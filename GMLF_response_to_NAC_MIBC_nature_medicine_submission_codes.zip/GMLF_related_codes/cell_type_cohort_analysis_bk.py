import numpy as np
import pandas as pd
import scipy.stats as stats
import pingouin as pg

ROOT_OUTPUT_DIR = '/home/zbai/tiatoolbox/Output/'

ct_features_df = pd.read_csv(f'{ROOT_OUTPUT_DIR}/interpretation_important_patch_summary.csv', index_col = 0)
cell_types = ['cancer', 'immune', 'connective', 'necrotic', 'non-cancer']
ct_features_df.index = cell_types
print(ct_features_df)
ct_features_prop_df = pd.DataFrame()
for col in ct_features_df.columns:
    ct_features_prop_df[col] = (ct_features_df[col] / ct_features_df[col].sum()) #* 100
print(ct_features_prop_df)

df_shap_values_test = pd.read_csv(f'{ROOT_OUTPUT_DIR}/CRvsRest_modality_features_test_predictions_shap.csv', index_col=0)
df_shap_values_valid = pd.read_csv(f'{ROOT_OUTPUT_DIR}/CRvsRest_modality_features_valid_predictions_shap.csv', index_col=0)
df_shap_values_train = pd.read_csv(f'{ROOT_OUTPUT_DIR}/CRvsRest_modality_features_train_predictions_shap.csv', index_col=0)

df_shap_values_all = pd.concat([df_shap_values_train, df_shap_values_valid, df_shap_values_test], ignore_index=True, axis=0)

print(df_shap_values_train)
print(df_shap_values_valid)
print(df_shap_values_test)
print(df_shap_values_all)

ct_count_t_coef = []
ct_count_t_pval = []
ct_prop_t_coef = []
ct_prop_t_pval = []

N = df_shap_values_all.shape[0]

ct_count_ttest_df = pd.DataFrame(columns=['T', 'dof', 'alternative', 'p-val', 'CI95%', 'cohen-d', 'BF10', 'power'])
ct_prop_ttest_df = pd.DataFrame(columns=['T', 'dof', 'alternative', 'p-val', 'CI95%', 'cohen-d', 'BF10', 'power'])

ct_count_kwtest_df = pd.DataFrame(columns=['statistic', 'pval']) 
ct_prop_kwtest_df = pd.DataFrame(columns=['statistic', 'pval'])

for ct in cell_types:
    ct_count = ct_features_df.loc[ct]
    ct_prop = ct_features_prop_df.loc[ct]
    print(ct_count)
    print(ct_prop)

    count_group1 = ct_count[df_shap_values_all.loc[df_shap_values_all['groundtruth CRvsRest'] == 1]['patient slide id']]
    count_group0 = ct_count[df_shap_values_all.loc[df_shap_values_all['groundtruth CRvsRest'] == 0]['patient slide id']]

    prop_group1 = ct_prop[df_shap_values_all.loc[df_shap_values_all['groundtruth CRvsRest'] == 1]['patient slide id']]
    prop_group0 = ct_prop[df_shap_values_all.loc[df_shap_values_all['groundtruth CRvsRest'] == 0]['patient slide id']]

    count_group1 = np.array(count_group1)
    count_group0 = np.array(count_group0)

    prop_group1 = np.array(prop_group1)
    prop_group0 = np.array(prop_group0)

    assert (len(count_group0) + len(count_group1)) == N, "Missing instances in count"

    assert (len(prop_group0) + len(prop_group1)) == N, "Missing instances in prop"

    print(f'Cell type counts T-test:')
    count_result = pg.ttest(count_group1, count_group0, correction=True)
    print(count_result)

    print(f'Cell type propotions T-test:')
    prop_result = pg.ttest(prop_group1, prop_group0, correction=True)
    print(prop_result)

    ct_count_ttest_df.loc[len(ct_count_ttest_df.index)] = count_result.loc['T-test']
    ct_prop_ttest_df.loc[len(ct_prop_ttest_df.index)] = prop_result.loc['T-test']

    print(f'Cell type counts KW-test:')
    count_result = stats.kruskal(count_group1, count_group0)
    print(count_result)
    ct_count_kwtest_df.loc[len(ct_count_kwtest_df.index)] = [count_result.statistic, count_result.pvalue]

    print(f'Cell type proportions KW-test:')
    prop_result = stats.kruskal(prop_group1, prop_group0)
    print(prop_result)
    ct_prop_kwtest_df.loc[len(ct_prop_kwtest_df.index)] = [prop_result.statistic, prop_result.pvalue]

ct_count_ttest_df.index = cell_types
ct_prop_ttest_df.index = cell_types

ct_count_kwtest_df.index = cell_types
ct_prop_kwtest_df.index = cell_types

#ct_count_ttest_df.to_csv(f'{ROOT_OUTPUT_DIR}/ct_count_ttest_df.csv')
#ct_prop_ttest_df.to_csv(f'{ROOT_OUTPUT_DIR}/ct_prop_ttest_df.csv')

ct_count_kwtest_df.to_csv(f'{ROOT_OUTPUT_DIR}/ct_count_kwtest_df.csv')
ct_prop_kwtest_df.to_csv(f'{ROOT_OUTPUT_DIR}/ct_prop_kwtest_df.csv')
